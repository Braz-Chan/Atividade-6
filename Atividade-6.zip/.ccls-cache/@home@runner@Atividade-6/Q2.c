#include <stdio.h>

int main() {
    int choice;
    
    printf("Menu:\n");
    printf("1. Hamburger - R$10.00\n");
    printf("2. Cheeseburger - R$12.00\n");
    printf("3. Hot Dog - R$8.00\n\n");
    
    printf("Escolha uma opção: ");
    scanf("%d", &choice);
    
    switch (choice) {
        case 1:
            printf("Você escolheu Hamburger!\n");
            printf("O preço é R$10.00\n");
            break;
        case 2:
            printf("Você escolheu Cheeseburger!\n");
            printf("O preço é R%12.00\n");
            break;
        case 3:
            printf("Você escolheu Hot Dog!\n");
            printf("O preço é R$8.00\n");
            break;
        default:
            printf("Opção inválida!\n");
            break;
    }
    
    return 0;
}