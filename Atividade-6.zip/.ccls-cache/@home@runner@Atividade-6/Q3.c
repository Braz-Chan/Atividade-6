#include <stdio.h>

int main() {
    int prato, sobremesa, bebida;
    int calorias = 0;
    
    printf("Escolha um prato:\n");
    printf("1 - Vegetariano\n");
    printf("2 - Peixe\n");
    printf("3 - Frango\n");
    printf("4 - Carne\n");
    scanf("%d", &prato);
    
    printf("\nEscolha uma sobremesa:\n");
    printf("1 - Abacaxi\n");
    printf("2 - Sorvete diet\n");
    printf("3 - Mouse diet\n");
    printf("4 - Mouse chocolate\n");
    scanf("%d", &sobremesa);
    
    printf("\nEscolha uma bebida:\n");
    printf("1 - Chá\n");
    printf("2 - Suco de laranja\n");
    printf("3 - Suco de melão\n");
    printf("4 - Refrigerante diet\n");
    scanf("%d", &bebida);
    
    switch (prato) {
        case 1:
            calorias += 180;
            break;
        case 2:
            calorias += 230;
            break;
        case 3:
            calorias += 250;
            break;
        case 4:
            calorias += 350;
            break;
    }
    
    switch (sobremesa) {
        case 1:
            calorias += 75;
            break;
        case 2:
            calorias += 110;
            break;
        case 3:
            calorias += 170;
            break;
        case 4:
            calorias += 200;
            break;
    }
    
    switch (bebida) {
        case 1:
            calorias += 20;
            break;
        case 2:
            calorias += 70;
            break;
        case 3:
            calorias += 100;
            break;
        case 4:
            calorias += 65;
            break;
    }
    
    printf("\nA quantidade total de calorias da refeição é: %d\n", calorias);
    
    return 0;
}